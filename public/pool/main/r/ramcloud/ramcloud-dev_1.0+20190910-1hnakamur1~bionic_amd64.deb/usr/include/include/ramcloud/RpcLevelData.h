// This file was generated automatically by genLevels.py.
// Do not modify by hand.
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
       0,   // PING
       0,   // PROXY_PING
       0,   // KILL
       2,   // CREATE_TABLE
       0,   // GET_TABLE_ID
       2,   // DROP_TABLE
       1,   // READ
       2,   // WRITE
       2,   // REMOVE
       0,   // ENLIST_SERVER
       0,   // GET_SERVER_LIST
       0,   // GET_TABLE_CONFIG
       1,   // RECOVER
       1,   // HINT_SERVER_CRASHED
       0,   // RECOVERY_MASTER_FINISHED
       0,   // ENUMERATE
       0,   // SET_MASTER_RECOVERY_INFO
       1,   // FILL_WITH_TEST_DATA
       2,   // MULTI_OP
       0,   // GET_METRICS
NO_LEVEL,   // undefined RPC
       0,   // BACKUP_FREE
       0,   // BACKUP_GETRECOVERYDATA
NO_LEVEL,   // undefined RPC
       0,   // BACKUP_STARTREADINGDATA
       0,   // BACKUP_WRITE
       0,   // BACKUP_RECOVERYCOMPLETE
NO_LEVEL,   // undefined RPC
       0,   // UPDATE_SERVER_LIST
       0,   // BACKUP_STARTPARTITION
NO_LEVEL,   // undefined RPC
NO_LEVEL,   // undefined RPC
       0,   // DROP_TABLET_OWNERSHIP
       1,   // TAKE_TABLET_OWNERSHIP
NO_LEVEL,   // undefined RPC
       1,   // GET_HEAD_OF_LOG
       1,   // INCREMENT
       0,   // PREP_FOR_MIGRATION
       1,   // RECEIVE_MIGRATION_DATA
       2,   // REASSIGN_TABLET_OWNERSHIP
       3,   // MIGRATE_TABLET
       0,   // IS_REPLICA_NEEDED
       0,   // SPLIT_TABLET
       0,   // GET_SERVER_STATISTICS
       0,   // SET_RUNTIME_OPTION
       0,   // GET_SERVER_CONFIG
       0,   // GET_BACKUP_CONFIG
NO_LEVEL,   // undefined RPC
       0,   // GET_MASTER_CONFIG
       0,   // GET_LOG_METRICS
       0,   // VERIFY_MEMBERSHIP
       0,   // GET_RUNTIME_OPTION
       0,   // GET_LEASE_INFO
       0,   // RENEW_LEASE
       0,   // SERVER_CONTROL
       1,   // SERVER_CONTROL_ALL
       0,   // GET_SERVER_ID
       1,   // READ_KEYS_AND_VALUE
       0,   // LOOKUP_INDEX_KEYS
       1,   // READ_HASHES
       1,   // INSERT_INDEX_ENTRY
       1,   // REMOVE_INDEX_ENTRY
       2,   // CREATE_INDEX
       1,   // DROP_INDEX
       0,   // DROP_INDEXLET_OWNERSHIP
       0,   // TAKE_INDEXLET_OWNERSHIP
       0,   // PREP_FOR_INDEXLET_MIGRATION
       2,   // SPLIT_AND_MIGRATE_INDEXLET
       3,   // COORD_SPLIT_AND_MIGRATE_INDEXLET
       1,   // TX_DECISION
       1,   // TX_PREPARE
       1,   // TX_REQUEST_ABORT
       1,   // TX_HINT_FAILED
       0,   // ECHO
       0,   // ILLEGAL_RPC_TYPE
